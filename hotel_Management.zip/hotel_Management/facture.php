<?php 
  session_start();
  include 'actions/getFactureAction.php';

  require 'vendor/autoload.php';

  // reference the Dompdf namespace
	use Dompdf\Dompdf;

	// instantiate and use the dompdf class
	$dompdf = new Dompdf();
	
$html = '
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/facture.css">
	<title>Facture</title>
</head>
<body>
	<div class="body">
		<div style="height: 50px;"></div>
		<div style="text-align: center;">
			<h1>Edems Hotel</h1>
		</div>
		<div style="height: 50px;"></div>
		<table>
			<thead>
					<th colspan="7"><h2>FACTURE</h2></th>
			</thead>
			<tbody>
				
				<tr>
					<td colspan="7">
						<div>
							<div class="lr">
								<div class="l">
									<p>Nom : '. $nom .'</p>
									<p>Prénom : '. $prenom .'</p>
								</div>
								<div class="r">
									<p>Email : '. $email .'</p>
									<p>Numéro :'. $tel .'</p>
								</div>
							</div>
						</div>
					</td>
				</tr>
				<tr>
					<td bgcolor="#c9bebe" colspan="7"></td>
				</tr>
				
			
				<tr>
					<td>Type de chambre</td>
					<td>Nombre de chambre</td>
					<td>Nombre de jour</td>
					<td>Reduction</td>
					<td>Date de reservation</td>
					<td colspan="2">Date de séjour</td>
				</tr>
				<tr>
					<td>'. $type .'</td>
					<td>'. $nombre_c .'</td>
					<td>'. $nombre_j .'</td>
					<td>'. $reduc .' %</td>
					<td>'. $dr .'</td>
					<td colspan="2">'. $ds .'</td>
				</tr>
				<tr>
					<td bgcolor="#c9bebe" colspan="7"></td>
				</tr>
				
			</tbody>
		</table>
		<div class="footer">
			<div>
				<p>Signature</p>
			</div>
			<div>
				<table>
					<tr>
						<td width="150px" align="center">A PAYER</td>
					</tr>
					<tr>
						<td height="25px"></td>
					</tr>
				</table>
				<br>
				<br>
				<br>
				<br>
				<br>
				<p>L AGENT COMPTABLE</p>
			</div>
			

		</div>
		
	</div>
</body>
</html>';
	$dompdf->loadHtml($html);

	// (Optional) Setup the paper size and orientation
	$dompdf->setPaper('A4', 'portrait');

	// Render the HTML as PDF
	$dompdf->render();

	// Output the generated PDF to Browser
	$dompdf->stream();
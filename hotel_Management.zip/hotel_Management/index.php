<?php 
session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<?php include 'include/head.php'; ?>
</head>
<body>
	<?php include 'include/navbar.php'; ?>

	<section class="section1">
		<div class="sec">
			<h1>BIENVENUE A NOTRE HOTEL</h1>
			<a href="reservation.php"><div class="button">RESERVER MAINTENANT</div></a>

			
		</div>	
	</section>
	<section class="section2">
		<div style="text-align: center; padding: 40px;">
			<h1>Nos services</h1>
		</div>
		<div class="container">
		  <div class="grid">
		      <div class="item">
		      	<img width="100%" src="assets/images/1.jpg">
		      	<h3>ACHAT DE PACKS</h3>
		      </div>
		      <div class="item">
		      	<img width="100%" src="assets/images/2.jpg">
		      	<h3>TOURISME</h3>
		      </div>
		      <div class="item">
		      	<img width="100%" src="assets/images/3.jpg">
		      	<h3>RESTAURATION</h3>
		      	
		      </div>
		     
		  </div>
		</div>
		
	</section>

	

	<?php include 'include/footer.php'; ?>
</body>
</html>	
<?php 
  require('actions/securityAction.php');
  include 'actions/updateReservationAction.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<?php include 'include/head.php'; ?>
    <link rel="stylesheet" type="text/css" href="assets/css/form.css">

</head>
<body>
	<?php include 'include/navbar.php'; ?>
	
	<div class="">
			<form action="" id="" method="POST">
				
				<br>
				<br>
			        <h1>Modifier ma réservation</h1>
			        <br>
			        <?php 
			        if (isset($error)) {            
			         ?>
			         <div style="color: white;, text-align: center; background-color: red ; padding: 15px;"> <?=$error ?></div>

			         <?php 
			        }
			          ?>

			          <?php 
			        if (isset($success)) {          
			         ?>
			         <div style="color: white;, text-align: center; background-color: green ; padding: 15px;"> <?=$success ?></div>
			         <?php 
			        }
			          ?>

			     <label for="" id="">Type de chambres</label>

			      <select name="type" >
			         <option value="CDD">Chambre Double Deluxe</option>
			         <option value="CDCo"> Chambre Double Confort.</option>
			         <option value="CJC"> Chambre lits Jumeaux Classique.</option>
			         <option value="CTE"> Chambre Triple Economique.</option>
			         <option value="CQF"> Chambre Quadruple Familiale.</option>
			         <option value="CGF">Chambre Quadruple Familiale (lit sup.)</option>
			         <option value="CDE">Chambre Double Economique</option>
			         <option value="CDCl">Chambre Double Classique</option>
			       </select>

			      <label for="" id="">Nombre de chambres</label>
			      <input type="number" name="nombre_c"  placeholder="Nombre de chambres" >

			      <label for="" id="">Nombre de jours</label>
			      <input type="number" name="nombre_j"  placeholder="Nombre de jours" >

			      <label for="" id="">Debut séjour</label>
			      <input type="date" name="date_s"  >

			      <button id="submit" name="validate" class="btn-submit" type="submit">Modifier</button>
			      
			    </form>

			    <div style="text-align: center; ">
					<a href="mes-reservation.php"><button class="btn-submit">Mes reservations</button></a>
				</div>
				<br>
				<br>
				<br>
				<br>
				<br>
		</div>
	


</body>
</html>
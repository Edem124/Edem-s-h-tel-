<header class="header">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="logo">
               <a href="#">EDEM'S HOTEL</a>
            </div>
            <button type="button" class="nav-toggler">
               <span></span>
            </button>
            <nav class="nav">
               <ul>
                  <li><a href="index.php" class="active">Acceuil</a></li>
                  <li><a href="reservation.php">Reservation</a></li>
                  <?php 
                   if (isset($_SESSION['auth'])) {
                    ?>
                  <li><a href="mes-reservation.php">Mes reservations</a></li>
                    <?php 
                     }
                       ?>
                 
                   <?php 
                   if (isset($_SESSION['auth'])) {
                    ?>
                   <li><a href="actions/logoutAction.php">Se déconnecter</a></li>
                    <?php 
                     }else{
                       ?>
                       <li><a href="login.php">Se connecter</a></li>
                       <?php 
                     }
                     ?>
                 
               </ul>
            </nav>
        </div>
    </div>
 </header>
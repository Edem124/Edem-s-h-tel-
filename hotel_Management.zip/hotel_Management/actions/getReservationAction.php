<?php 
	require('database.php');

	$idOfUser = $_SESSION['id'];

	$getAllR = $bdd->query("SELECT * FROM reservation WHERE id_user = '$idOfUser' ");

	$getAllReserv = $bdd->query("SELECT * FROM reservation ");

	$getAllUser = $bdd->query("SELECT * FROM users ");

 ?>
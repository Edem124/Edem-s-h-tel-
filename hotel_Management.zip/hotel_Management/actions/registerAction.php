<?php
session_start();
include 'actions/database.php';
$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if (isset($_POST['validate'])) {
	if (!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['tel']) AND !empty($_POST['email']) AND !empty($_POST['password1']) AND! empty($_POST['password2']) ) {

		$nom = htmlspecialchars($_POST['nom']);
		$prenom = htmlspecialchars($_POST['prenom']);
		$email = htmlspecialchars($_POST['email']);
		$tel = htmlspecialchars($_POST['tel']);
		$pass = password_hash($_POST['password1'], PASSWORD_DEFAULT);
		$pass2 = password_hash($_POST['password2'], PASSWORD_DEFAULT);
		$date = date('d/m/Y');

		if ($_POST['password1'] == $_POST['password2']) {
			$checkIfUserAlreadyExists = $bdd->prepare('SELECT email FROM users WHERE email = ?');
	        $checkIfUserAlreadyExists->execute(array($email));

	        if($checkIfUserAlreadyExists->rowCount() == 0){
	            
	            //Insérer l'utilisateur dans la bdd
	            $insertUserOnWebsite = $bdd->prepare('INSERT INTO users(nom, prenom, tel, email, password)VALUES(?, ?, ?, ?, ?)');
	            $insertUserOnWebsite->execute(array($nom,$prenom,$tel, $email, $pass));

	           

	           

	            header('Location: index.php');
	        }else {
	            $error = "L'utilisateur existe déjà sur le site";
	        }
		}else {
			$error = "Vos mots de passe ne sont identiques";
		}

	}else {
		$error = "Veuillez remplir tous les champs";
	}
}

?>
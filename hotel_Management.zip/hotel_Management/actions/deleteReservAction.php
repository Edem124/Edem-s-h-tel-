<?php

require('database.php');

if(isset($_GET['id']) AND !empty($_GET['id'])){

    $idOfR = $_GET['id'];

    $checkIfReservExists = $bdd->prepare('SELECT * FROM reservation WHERE id = ?');
    $checkIfReservExists->execute(array($idOfR));

    if($checkIfReservExists->rowCount() > 0){


        $delete = $bdd->prepare('DELETE FROM reservation WHERE id = ?');
        $delete->execute(array($idOfR));

        header('Location: ../mes-reservation.php');

    }else{
        header('Location: ../mes-reservation.php');
    }
}else{
    header('Location: ../mes-reservation.php');
}
<?php

require('database.php');

if(isset($_POST['validate']) ){

    if(!empty($_POST['type']) AND !empty($_POST['nombre_c']) AND !empty($_POST['nombre_j']) AND !empty($_POST['date_s'])) {
        
        //Les données de la question
        $idOfUser = $_SESSION['id'];
        $idOfR = $_GET['id'];
        $type = htmlspecialchars($_POST['type']);
        $nombre_c = htmlspecialchars($_POST['nombre_c']);
        $nombre_j = htmlspecialchars($_POST['nombre_j']);
        $date_s = htmlspecialchars($_POST['date_s']);
        if ($nombre_j >= 3) {
            $reduc = 10;
        }else{
            $reduc = 0;
        }
        
        

        $update = $bdd->prepare('UPDATE reservation SET type = ?, nombre_c = ?, nombre_j = ?, reduction = ?, date_s = ? WHERE id = ?');
        $update->execute(array($type, $nombre_c, $nombre_j,$reduc, $date_s, $idOfR));

        $success = "Reservation enregistré avec succès";
        header('Location: mes-reservation.php');
        
    }else{
        $error= "Veuillez compléter tous les champs...";
    }

}
<?php

require('database.php');

if(isset($_POST['validate']) ){

    if(!empty($_POST['type']) AND !empty($_POST['nombre_c']) AND !empty($_POST['nombre_j']) AND !empty($_POST['date_s'])) {
        
        //Les données de la question
        $idOfUser = $_SESSION['id'];
        $type = htmlspecialchars($_POST['type']);
        $nombre_c = htmlspecialchars($_POST['nombre_c']);
        $nombre_j = htmlspecialchars($_POST['nombre_j']);
        $date_s = htmlspecialchars($_POST['date_s']);
        if ($nombre_j >= 3) {
            $reduc = 10;
        }else{
            $reduc = 0;
        }
        
        $insert = $bdd->prepare('INSERT INTO reservation(id_user, type, nombre_c, nombre_j,reduction, date_s)VALUES(?, ?, ?, ?, ?, ?)');
        $insert->execute(
            array(
                $idOfUser,
                $type,
                $nombre_c,
                $nombre_j,
                $reduc,
                $date_s
            ));

        $success = "Reservation enregistré avec succès";
        
    }else{
        $error= "Veuillez compléter tous les champs...";
    }

}
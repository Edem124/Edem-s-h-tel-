<?php
session_start();
require('actions/database.php');



//Validation du formulaire
if(isset($_POST['envoi'])){

    //Vérifier si l'user a bien complété tous les champs
    if(!empty($_POST['email']) AND !empty($_POST['password'])){
        
        //Les données de l'user
        $email = htmlspecialchars($_POST['email']);
        $password = htmlspecialchars($_POST['password']);

        //Vérifier si l'utilisateur existe 
        $checkIfUserExists = $bdd->prepare('SELECT * FROM users WHERE email = ?');
        $checkIfUserExists->execute(array($email));

        if($checkIfUserExists->rowCount() > 0){
            
            //Récupérer les données de l'utilisateur
            $usersInfos = $checkIfUserExists->fetch();

            //Vérifier si le mot de passe est correct
            if(password_verify($password, $usersInfos['password'])){
            
                //Authentifier l'utilisateur sur le site et récupérer ses données dans des variables globales sessions
               
                $_SESSION['auth'] = true;
                $_SESSION['id'] = $usersInfos['id'];
                $_SESSION['nom'] = $usersInfos['nom'];
                $_SESSION['prenom'] = $usersInfos['prenom'];
                $_SESSION['email'] = $usersInfos['email'];


                //Rediriger l'utilisateur vers la page d'accueil
                header('Location: index.php');
    
            }else{
                $error = "Votre mot de passe est incorrect...";
            }

        }else{
            $error = "Votre email est incorrect...";
        }

    }else{
        $error = "Veuillez compléter tous les champs...";
    }

}
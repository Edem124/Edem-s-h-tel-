<?php  
require('database.php');

if(isset($_GET['id']) AND !empty($_GET['id'])){

    $idOfR = $_GET['id'];

    $checkIfReservExists = $bdd->prepare('SELECT * FROM reservation WHERE id = ?');
    $checkIfReservExists->execute(array($idOfR));

    if($checkIfReservExists->rowCount() > 0){

        $info = $checkIfReservExists->fetch();

        $id_u = $info['id_user'];
        $type = $info['type'];
        $nombre_c = $info['nombre_c'];
        $nombre_j = $info['nombre_j'];
        $reduc = $info['reduction'];
        $dr = $info['date_r'];
        $ds = $info['date_s'];

        $getUserInfo = $bdd->prepare('SELECT * FROM users WHERE id = ?');
        $getUserInfo->execute(array($id_u));

        $userinfo = $getUserInfo->fetch();
        $nom = $userinfo['nom'];
        $prenom = $userinfo['prenom'];
        $email = $userinfo['email'];
        $tel = $userinfo['tel'];
        

    }else{
        header('Location: ../mes-reservation.php');
    }
}else{
    header('Location: ../mes-reservation.php');
}



?>
<?php 
include 'actions/registerAction.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
   
    <link rel="stylesheet" type="text/css" href="assets/css/form.css">
</head>
<body>

    <form action="" id="" method="POST">
        <h1>Inscription</h1>
        <?php 
        if (isset($error)) {            
         ?>
         <div style="color: white;, text-align: center; background-color: red ; padding: 15px;"> <?=$error ?></div>

         <?php 
        }
          ?>

          <?php 
        if (isset($success)) {          
         ?>
         <div style="color: white;, text-align: center; background-color: green ; padding: 15px;"> <?=$success ?></div>

         <?php 
        }
          ?>
      

      <label for="nom" id="">Nom</label>
      <input type="text" name="nom" id="nom" placeholder="Votre nom" >

       <label for="prenom" id="">Prénom</label>
      <input type="text" name="prenom" id="prenom" placeholder="Votre Prénom" >

       <label for="tel" id="">Tel</label>
      <input type="number" name="tel" id="tel" placeholder="Votre telephone" >

      <label for="tel" id="">Email</label>
      <input type="email" name="email" id="email" placeholder="Votre email" >

      <label for="password1" id="">Mot de passe</label>
      <input type="password" name="password1" id="password1" placeholder="Votre mot de passe" >

      <label for="password2" id="">Confirmer</label>
      <input type="password" name="password2" id="password2" placeholder="Confirmer votre mot de passe" >
      

      <button id="submit" name="validate" class="btn-submit" type="submit">Valider</button>
      <br>
      <br>
      <a href="login.php"><div>Se connecter</div></a>
    </form>

</body>
</html>
<?php 
  require('actions/securityAction.php');
  include 'actions/getReservationAction.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<?php include 'include/head.php'; ?>
    <link rel="stylesheet" type="text/css" href="assets/css/form.css">

</head>
<body>
	<?php include 'include/navbar.php'; ?>
	
	<div class="">
		<table>
  <caption>Mes réservations</caption>
  <thead>
    <tr>
     
      <th scope="col">Type de reservation</th>
      <th scope="col">Nombre de chambre</th>
      <th scope="col">Nombre de jour</th>
      <th scope="col">Reduction</th>
      <th scope="col">Date du sejour</th>
      <th scope="col">Date de resrvation</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  	<?php 
   while($info = $getAllR->fetch()){
   ?>
               
     
    <tr>
      <td ><?= $info['type'] ?></td>
      <td ><?= $info['nombre_c'] ?></td>
      <td ><?= $info['nombre_j'] ?></td>
      <td ><?= $info['reduction'] ?>%</td>
      <td ><?= $info['date_s'] ?></td>
      <td ><?= $info['date_r'] ?></td>
      <td > 
      	<a href="facture.php?id=<?= $info['id']?>"><div>Telecharger facture</div></a>
      	<a href="modifier-reservation.php?id=<?= $info['id']?>"><div>Modifier</div></a>
      	<a href="actions/deleteReservAction.php?id=<?= $info['id']?>"  onclick="return confirm('Voulez vous vraiment supprimer cette réservations ?');" ><div>Supprimer</div></a>

      </td>
      
    </tr>
     <?php
      }
      ?>
   
  </tbody>
</table>
<style type="text/css">
	
table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}

table caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;

  }
  
  table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

</style>
			
	</div>

</body>
</html>
<?php 
include 'actions/loginAction.php';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
   
    <link rel="stylesheet" type="text/css" href="assets/css/form.css">
</head>
<body>

    <form action="" id="" method="POST">
        <h1>Se connecter</h1>
        <?php 
        if (isset($error)) {            
         ?>
         <div style="color: white;, text-align: center; background-color: red ; padding: 15px;"> <?=$error ?></div>

         <?php 
        }
          ?>

          <?php 
        if (isset($success)) {          
         ?>
         <div style="color: white;, text-align: center; background-color: green ; padding: 15px;"> <?=$success ?></div>

         <?php 
        }
          ?>

     <label for="tel" id="">Email</label>
      <input type="email" name="email" id="email" placeholder="Votre email" >

      <label for="password1" id="">Mot de passe</label>
      <input type="password" name="password" id="password1" placeholder="Votre mot de passe" >

      <button id="submit" name="envoi" class="btn-submit" type="submit">Valider</button>
      
      <br>
      <br>
      <a href="register.php"><div>S'inscrire</div></a>
    </form>

</body>
</html>